Golf Dataset:
The goal is to judge if weather conditions are suitable for playing golf. 
The class label is Yes (suitable for playing golf) or No (not suitable).
There are four attributes, and each attribute's possible values are listed below:
outlook: overcast, rainy, sunny
temperature: hot, mild, cool
humidity: high, normal
windy: true, false

Car Dataset:
The goal is to judge if buying a particular car is a good decision.
The class label is  unacc (unacceptable), acc (acceptable), good, vgood (very good)
There are three attributes, and each attribute's possible values are listed below:
number of passengers: 2, 4, more 
trunk size: small, med, big 
safety: low, med, high 



